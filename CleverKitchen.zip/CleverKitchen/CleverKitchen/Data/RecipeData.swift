//
//  RecipeData.swift
//  CleverKitchen
//
//  Created by Mahadevan Jeevahasan on 12/5/22.
//

import SwiftUI

//MARK: -RECIPE DATA

let recipesData: [RecipeModel] = [
    RecipeModel(
        title: "Chicken",
        headline: "Chicken",
        image: "",
        ingredients: [
        "Chicken","Garlic"],
        description: "How to make chicken"
    )
]

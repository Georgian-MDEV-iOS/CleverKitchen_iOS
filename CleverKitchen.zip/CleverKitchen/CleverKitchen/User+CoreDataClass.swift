//
//  User+CoreDataClass.swift
//  CleverKitchen
//
//  Created by Chandu on 2022-12-06.
//
//

import Foundation
import CoreData


public class User: NSManagedObject {

}
